package com.codegen.app.backend.codegen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodegenApplicationTests {

	@Test
	void contextLoads() {
	}

}
